function exibirPromocao() {
  var preco = parseFloat(document.getElementById("entradaText").value);
  if (isNaN(preco) || preco <= 0) {
      alert("Por favor, insira um preço válido.");
      return;
  }
  
  var precoSemDecimais = Math.floor(preco);
  var precoFinal = precoSemDecimais * 2;
  var mensagem = `Pague 2 por R$ ${precoFinal},00`;
  document.getElementById("resultad").innerText = mensagem;
}
