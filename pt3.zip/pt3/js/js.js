    function mostrarPromocao() {
      let nome = document.getElementById("produto").value;
      let preco = Number(document.getElementById("preco").value);
      let desconto = preco / 2;
      let total = (2 * preco) + desconto;
      document.getElementById("mensagem1").innerText = `${nome} - Promoção: Leve 3 por R$: ${total.toFixed(2)}`;
      document.getElementById("mensagem2").innerText = `O 3º produto custa apenas R$: ${desconto.toFixed(2)}`;
    }